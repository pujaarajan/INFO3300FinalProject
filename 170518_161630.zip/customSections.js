/**
 * scrollVis encapsulates all the code for using reusable charts pattern.
 * source: http://bost.ocks.org/mike/chart/
 * @return chart, func that contains all vis elements.
 */
var scrollVis = function() {
  // dimension of the vis area
  var width = 800, height = 520;
  var margin = {top: 0, left: 20, bottom: 40, right: 10};

  // to keep track of which vis to render
  var lastIndex = -1, activeIndex = 0;

  var svg = null, g = null;

  // set the domain for when data are processed
  var x = d3.scaleTime().rangeRound([0, width]);
  var y = d3.scaleLinear().rangeRound([height, 0]);

  // init axes for time series
  var xAxisTime = d3.axisBottom().scale(x)
  .ticks(3)
  .tickSizeInner(10)
  .tickSizeOuter(7);

  var yAxisClose = d3.axisLeft().scale(y)
  .ticks(3, '$,s')
  .tickSizeInner(-10)
  .tickSizeOuter(7);

  // init axes for bar chart
  var xBarScale = d3.scaleBand()
  .domain(d3.range(rev.length)).rangeRound([0, width]).padding(0.1);

  var yBarScale = d3.scaleLinear()
  .domain([0, 160000]).rangeRound([0, height]);

  var activateFunctions = [], updateFunctions = [];

  /**
   * This function draws the visualization in specified selection.
   * @param {d3.selection} selection current d3.selection()
   */
  var chart = function(selection) {
    selection.each(function(rawData) {
      svg = d3.select(this).selectAll('svg').data([stockData]);
      var svgE = svg.enter().append('svg');
      // combine enter and existing selection
      svg = svg.merge(svgE);

      svg.attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g');

      // this group element will be used to contain all
      // other elements.
      g = svg.select('g')
        .attr('transform', 'translate(${margin.left}, ${margin.top})');

      g.append('clipPath')
        .attr('id', 'clip')
      .append('rect')
        .attr('width', width)
        .attr('height', height);

      // perform some preprocessing on raw data
      var stockData = getStock(rawData);

      // set the line chart domains
      x.domain(d3.extent(stockData, function(d) { return d.date; }));
      y.domain(d3.extent(stockData, function(d) { return d.close; })).nice();

      setupVis(stockData);
      setupSections();
    });
  };

  /**
   * Creates initial elements for all sections of the visualization.
   * @param {Array} stockData data object for daily closing price.
   */
  var setupVis = function(stockData) {
    // title
    g.append('text')
      .attr('class', 'title apple-title')
      .attr('x', width / 2)
      .attr('y', height / 3)
      .text('How does the stock market');

    g.append('text')
      .attr('class', 'sub-title apple-title')
      .attr('x', width / 2)
      .attr('y', (height / 3) + (height / 5))
      .text("hype about the iPhone's");

    g.selectAll('.apple-title')
      .attr('opacity', 0);

    g.append('g')
      .attr('class', 'x axis')
      .attr('transform', 'translate(0,' + height + ')')
      .call(xAxisTime);

    g.append('g')
      .attr('class', 'y axis')
      .call(yAxisClose)
    .selectAll('text')
      .attr('y', -10)
      .attr('x', 0)
      .attr('dy', '.35em')
      .attr('transform', 'rotate(-90)')
      .attr('transform', 'translate(' + margin.left + ',0)')
      .style('text-anchor', 'start');

    g.select('.x.axis').style('opacity', 0);
    g.select('.y.axis').style('opacity', 0);

    // init line chart generator
    var line = d3.line()
    .x(d => x(d.date))
    .y(d => y(d.close));

    g.datum(stockData).on('click', click);

    g.append('path')
      .attr('class', 'line')
      .attr('clip-path', 'url(#clip)')
      .attr("d", line)
      .attr('transform', 'translate(' + margin.left + ',0)')
      .attr('opacity', 0);

    // generate selected circles
    g.selectAll('.dot')
      .data(stockData)
    .enter().append('circle')
      .filter(function(d) { return d.close === 97.53 || d.close === 112.91 || d.close === 114.09; })
      .attr('class', 'dot')
      .attr('cx', d => x(d.date))
      .attr('cy', d => y(d.close))
      .attr('transform', 'translate(' + margin.left + ',0)')
      .attr('opacity', 0);

    g.selectAll('.dots')
       .data(stockData)
      .enter().append('circle')
        .attr('class', 'dots')
        .attr('cx', d => x(d.date))
        .attr('cy', d => y(d.close))
        .attr('transform', 'translate(' + margin.left + ',0)')
        .attr('opacity', 0.1);

    g.selectAll('.text')
      .data(stockData)
    .enter().append('text')
      .filter(function(d) { return d.close === 97.53 || d.close === 112.91 || d.close === 114.09; })
      .attr('class', 'annotation text')
      .attr('x', function(d) { return x(d.date) + 10; })
      .attr('y', function(d) { return y(d.close - 10); })
      .text(function(d, i) {
        if (i===0) { return "iPhone 6/6 Plus Release"}
        else if (i===1) { return "iPhone 6S/6S Plus Release"}
        else if (i===2) { return "iPhone 7/7 Plus Release"}
      });

    // set up bar charts
    g.selectAll("rect")
     .data(rev).enter()
     .append("rect")
     .attr('class', 'rect')
     .attr("x", (d, i) => xBarScale(i))
     .attr("y", d => (height - yBarScale(d.sales['2014'])))
     .attr("width", xBarScale.bandwidth())
     .attr("height", d => yBarScale(d.sales['2014']))
     .attr("fill", d => "rgb(0, 0, " + (d.sales['2014'] * 10) + ")")
     .attr('opacity', 0);

    // bar chart annotation
    g.selectAll('text-bar')
    .data(rev).enter()
    .append('text')
    .attr('class', 'text-bar')
    .text(d => d.product)
    .attr('text-anchor', 'middle')
    .attr('x', (d, i) => xBarScale(i) + xBarScale.bandwidth() / 2)
    .attr('y', d => height - yBarScale(d.sales['2014']) + 14)
    .attr('font-family', 'sans-serif')
    .attr('font-size', '11px')
    .attr('fill', 'black')
    .attr('opacity', 0);

    // update bar chart data
    d3.selectAll('rect').on('click', function() {
      var data = rev;

      g.selectAll('rect')
      .data(data).transition()
      .attr('y', d => height - yBarScale(d.sales[2015]))
      .attr('height', d => yBarScale(d.sales[2015]))
      .attr('fill', d => "rgb(0, 0, " + (d.sales['2015'] * 10) + ")")

      g.selectAll('text-bar')
      .data(data)
      .text( d => d.product)
      .attr('y', d => height - yBarScale(d.sales['2015']) + 14);
    })


    // code to switch view on time-series data
    function click() {
      var n = stockData.length - 1,
          i = Math.floor(Math.random() * n / 2),
          j = i + Math.floor(Math.random() * n / 2) + 1;
      x.domain([stockData[i].date, stockData[j].date]);
      var t = g.transition().duration(200);
      t.select('.x.axis').call(xAxisTime);
      t.select('.y.axis').call(yAxisClose);
      t.select('.line').attr('d', line);
      t.selectAll('.dots').remove();
    }
  }

  /** Each section is activated by a separate function. */
  var setupSections = function() {
    activateFunctions[0] = showTitle;
    activateFunctions[1] = showLine;
    activateFunctions[2] = showCircles;
    activateFunctions[3] = showBars;
    activateFunctions[4] = showDrawIt;
  }

  /** Shows initial title and hides axis and line chart. */
  function showTitle() {
    g.selectAll('.apple-title')
      .transition()
      .duration(600)
      .attr('opacity', 1.0);

    g.selectAll('.line')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.dot')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.text')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.dots')
    .transition()
    .duration(600)
    .attr('opacity', 0.1);

    g.selectAll('.rect')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.text-bar')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    hideAxis();
  }

  /** Shows axis and hides initial title. */
  function showLine() {
    g.selectAll('.apple-title')
      .transition()
      .duration(0)
      .attr('opacity', 0);

    g.selectAll('.line')
      .transition()
      .duration(600)
      .attr('opacity', 1);

    g.selectAll('.dot')
    .transition()
    .duration(600)
    .attr('opacity', 1);

    g.selectAll('.dots')
    .transition()
    .attr('opacity', 1);

    g.selectAll('.text')
    .transition()
    .duration(600)
    .attr('opacity', 1);

    showXAxis(xAxisTime);
    showYAxis(yAxisClose);
  }

  /** Shows dates when iPhones are released. */
  function showCircles() {
    g.selectAll('.dot')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.dots')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.text')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.line')
      .transition()
      .duration(600)
      .attr('opacity', 1);

      g.selectAll('.rect')
      .transition()
      .duration(600)
      .attr('opacity', 0);

      g.selectAll('.text-bar')
      .transition()
      .duration(600)
      .attr('opacity', 0);

    showXAxis(xAxisTime);
    showYAxis(yAxisClose);
  }

  /** Shows bar charts. */
  function showBars() {
    hideAxis();

    g.selectAll('.dot')
    .transition()
    .duration(300)
    .attr('opacity', 0);

    g.selectAll('.line')
      .transition()
      .duration(600)
      .attr('opacity', 0);

    g.selectAll('.rect')
    .transition()
    .duration(600)
    .attr('opacity', 1);

    g.selectAll('.text-bar')
    .transition()
    .duration(600)
    .attr('opacity', 1);

  }

  function showDrawIt() {
    g.selectAll('.dots')
    .transition()
    .duration(300)
    .attr('opacity', 0);

    g.selectAll('.text')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.rect')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    g.selectAll('.text-bar')
    .transition()
    .duration(600)
    .attr('opacity', 0);

    showAxis();
  }

  /**
   * Displays chosen axis.
   * @param axis, the axis to show
   */
  function showXAxis(axis) {
    g.select('.x.axis')
      .call(axis)
      .transition().duration(600)
      .style('opacity', 1);
  }

  function showYAxis(axis) {
    g.select('.y.axis')
      .call(axis)
      .transition().duration(600)
      .style('opacity', 1);
  }

  /** Hides all axes. */
  function hideAxis() {
    g.select('.x.axis')
      .transition().duration(600)
      .style('opacity', 0);

    g.select('.y.axis')
      .transition().duration(600)
      .style('opacity', 0);
  }

  /**
   * Maps raw data to array of data objects.
   * @param rawData, data read in from file
   */
  function getStock(rawData) {
    var parseTime = d3.timeParse("%m/%d/%y");
    return rawData.map(function(d) {
      d.date = parseTime(d.date);
      d.close = +d.close;
      return d;
    });
  }



  /**
   * Activates vis set up within chart func.
   * @param {Number} index index of the activated section
   */
  chart.activate = function(index) {
    activeIndex = index;
    var sign = (activeIndex - lastIndex) < 0 ? -1 : 1;
    var scrolledSections = d3.range(lastIndex + sign, activeIndex + sign, sign);
    scrolledSections.forEach(function (i) {
      activateFunctions[i]();
    });
    lastIndex = activeIndex;
  };

  /**
   * Updates vis set up within chart func.
   * @param  {Number} index
   * @param  {Number} progress [0.0, 1.0] denotes how far user has scrolled in section
   */
  chart.update = function(index, progress) {
    updateFunctions[index](progress);
  }
  return chart;
};


/**
 * Sets up the scroller and displays the visualization.
 * @param {Array} data loaded array of data objects
 */
function display(data) {
  var plot = scrollVis();

  d3.select('#vis')
    .datum(data)
    .call(plot);

  // setup scroll functionality
  var scroll = scroller().container(d3.select('#graphic'));

  // pass in .step selection as the steps
  scroll(d3.selectAll('.step'));

  // set up event handling
  scroll.on('active', function (index) {
    // highlight current step text
    d3.selectAll('.step')
      .style('opacity', function (d, i) { return i === index ? 1 : 0.1; });
    // activate current section
    plot.activate(index);
  });
}


// load data and display
d3.csv('data.csv', display);

/** Apple product revenue */
var rev = [
  {
    'product': 'iPhone',
    'sales': {
       '2014': 101991,
       '2015': 155041,
       '2016': 136700
    }
  },
  {
    'product': 'iPad',
    'sales': {
       '2014': 30283,
       '2015': 23227,
       '2016': 20628
    }
  },
  {
    'product': 'Mac',
    'sales': {
       '2014': 18063,
       '2015': 25471,
       '2016': 22831
    }
  }
]
